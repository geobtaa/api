Report evidence: all
UTC interval: 2026-07-01 inclusive to 2026-11-01 exclusive
Report revision: fd437b3eb2879a477e3cdb9edec1c7b8ca7cac544aa65d1cb31dabd49ee168b5
Report checksum: 056e27e5f02bde8237154cbd5bb014acfa163be5c06f25ae388fd6214c8e934c
Evidence checksum: abdaac0f5a60e95086b2d7ed47fdc1b1b28e05e4fa03b0f98e346380bae4433a
Calculation version: 3
Declared source coverage: incomplete

Verification:
- reportIntegrity: passed
- dailyCalendar: passed
- preservedInputReplay: passed
- independentBaselineEvidence: not-verified
- deployedPreservation: not-verified

Daily-to-period reconciliation:
- requests: reported=4896112; daily sum=4896112; passed
- searches: reported=27511; daily sum=27511; passed
- views: reported=50714; daily sum=50714; passed
- downloads: reported=3172; daily sum=3172; passed
- sourceClicks: reported=3918; daily sum=3918; passed
- impressions: reported=425509; daily sum=425509; passed

Definitions:
- requests: Recorded API requests, including automated traffic and probes.
- searches: Recorded search events; repeated searches count separately.
- views: Recorded resource-view events, not all website pageviews or unique people.
- downloads: Recorded download-link clicks, not confirmed file transfers.
- sourceClicks: Recorded source-site link clicks, not confirmed visits or transfers.
- impressions: Recorded appearances of resources in search results.
- trackedVisits: An estimate from merged tab-scoped token sketches; not unique people. Daily estimates must not be added to obtain a period estimate.
- latency: Response times for recorded API requests. Percentiles cannot be added or averaged across months; historical values may come from preserved baselines.

Limitations:
- Reconciliation establishes consistency of recorded data, not capture of every real-world interaction.
- Coverage is the report's recorded declaration, not an independent certification.
- Independent baseline documents and deployed archive durability were not verified by this packet.
- This packet covers the aggregate report only. Detailed rankings, member attribution, client classifications and supplemental dashboard data are outside its verification scope.
- Catalog attribution uses captured metadata, which need not represent month-end inventory.
- Checksums detect changed content; they are not signatures or independent attestations.

Input archive hashes, catalog capture dates, and source-count checks (when supplied) are in evidence.json. Original receipts remain private.
Checksums use SHA-256 over UTF-8 JSON with sorted keys and compact separators. For the report revision omit revision; for the evidence checksum omit evidenceChecksum. The report checksum includes revision. This packet has no external signature.
