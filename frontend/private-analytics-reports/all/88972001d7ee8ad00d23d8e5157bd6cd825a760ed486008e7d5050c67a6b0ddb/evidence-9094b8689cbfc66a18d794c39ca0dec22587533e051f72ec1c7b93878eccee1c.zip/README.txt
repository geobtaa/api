Report evidence: all
UTC interval: 2026-07-01 inclusive to 2026-10-01 exclusive
Report revision: 88972001d7ee8ad00d23d8e5157bd6cd825a760ed486008e7d5050c67a6b0ddb
Report checksum: ff1a36ecd248cd955c6943bbb35641ff1190c9562633f9d38842dc3313fcf697
Evidence checksum: 9094b8689cbfc66a18d794c39ca0dec22587533e051f72ec1c7b93878eccee1c
Calculation version: 3
Declared source coverage: incomplete

Verification:
- reportIntegrity: passed
- dailyCalendar: passed
- preservedInputReplay: passed
- independentBaselineEvidence: not-verified
- deployedPreservation: not-verified

Daily-to-period reconciliation:
- requests: reported=1687970; daily sum=1687970; passed
- searches: reported=19538; daily sum=19538; passed
- views: reported=40137; daily sum=40137; passed
- downloads: reported=2621; daily sum=2621; passed
- sourceClicks: reported=2869; daily sum=2869; passed
- impressions: reported=294620; daily sum=294620; passed

Definitions:
- requests: Recorded API requests, including automated traffic and probes.
- searches: Recorded search events; repeated searches count separately.
- views: Recorded resource-view events, not all website pageviews or unique people.
- downloads: Recorded download-link clicks, not confirmed file transfers.
- sourceClicks: Recorded source-site link clicks, not confirmed visits or transfers.
- impressions: Recorded appearances of resources in search results.
- trackedVisits: An estimate from merged tab-scoped token sketches; not unique people. Daily estimates must not be added to obtain a period estimate.
- latency: Response times for recorded API requests. Percentiles cannot be added or averaged across months; historical values may come from preserved baselines.

Limitations:
- Reconciliation establishes consistency of recorded data, not capture of every real-world interaction.
- Coverage is the report's recorded declaration, not an independent certification.
- Independent baseline documents and deployed archive durability were not verified by this packet.
- This packet covers the aggregate report only. Detailed rankings, member attribution, client classifications and supplemental dashboard data are outside its verification scope.
- Catalog attribution uses captured metadata, which need not represent month-end inventory.
- Checksums detect changed content; they are not signatures or independent attestations.

Input archive hashes, catalog capture dates, and source-count checks (when supplied) are in evidence.json. Original receipts remain private.
Checksums use SHA-256 over UTF-8 JSON with sorted keys and compact separators. For the report revision omit revision; for the evidence checksum omit evidenceChecksum. The report checksum includes revision. This packet has no external signature.
