Report evidence: 2026-08
UTC interval: 2026-08-01 inclusive to 2026-09-01 exclusive
Report revision: c8d04ac4fced0608fb73323e2c864b0bea87a9da876e95d754169684f126a9fc
Report checksum: 8ac12a14fd833cc2352851c9caeae9210d8d2888a6f21045f885236c9222521c
Evidence checksum: 40244761162af1b38ffed2a4baaca8af9becfa3c533c36e5265028acb4f83c91
Calculation version: 3
Declared source coverage: complete

Verification:
- reportIntegrity: passed
- dailyCalendar: passed
- preservedInputReplay: passed
- independentBaselineEvidence: not-verified
- deployedPreservation: not-verified

Daily-to-period reconciliation:
- requests: reported=598931; daily sum=598931; passed
- searches: reported=7545; daily sum=7545; passed
- views: reported=17440; daily sum=17440; passed
- downloads: reported=812; daily sum=812; passed
- sourceClicks: reported=858; daily sum=858; passed
- impressions: reported=104455; daily sum=104455; passed

Definitions:
- requests: Recorded API requests, including automated traffic and probes.
- searches: Recorded search events; repeated searches count separately.
- views: Recorded resource-view events, not all website pageviews or unique people.
- downloads: Recorded download-link clicks, not confirmed file transfers.
- sourceClicks: Recorded source-site link clicks, not confirmed visits or transfers.
- impressions: Recorded appearances of resources in search results.
- trackedVisits: An estimate from merged tab-scoped token sketches; not unique people. Daily estimates must not be added to obtain a period estimate.
- latency: Response times for recorded API requests. Percentiles cannot be added or averaged across months; historical values may come from preserved baselines.

Limitations:
- Reconciliation establishes consistency of recorded data, not capture of every real-world interaction.
- Coverage is the report's recorded declaration, not an independent certification.
- Independent baseline documents and deployed archive durability were not verified by this packet.
- This packet covers the aggregate report only. Detailed rankings, member attribution, client classifications and supplemental dashboard data are outside its verification scope.
- Catalog attribution uses captured metadata, which need not represent month-end inventory.
- Checksums detect changed content; they are not signatures or independent attestations.

Input archive hashes, catalog capture dates, and source-count checks (when supplied) are in evidence.json. Original receipts remain private.
Checksums use SHA-256 over UTF-8 JSON with sorted keys and compact separators. For the report revision omit revision; for the evidence checksum omit evidenceChecksum. The report checksum includes revision. This packet has no external signature.
