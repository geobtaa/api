Report evidence: 2026-08
UTC interval: 2026-08-01 inclusive to 2026-09-01 exclusive
Report revision: c79706a0f2f6d27d44bc8c0352c56c0f4e81ce5f7941909d420613a21f0ebcee
Report checksum: fc0bc271d2cc091fef386b3b8461bf0cfa5785a3cae61ccd52fdc78253735388
Evidence checksum: a8425e5aaae5c9e6df70dcca9026c7a5f2e86c745b181db9d38c837a9d4c2e59
Calculation version: 3
Declared source coverage: complete

Verification:
- reportIntegrity: passed
- dailyCalendar: passed
- preservedInputReplay: passed
- independentBaselineEvidence: not-verified
- deployedPreservation: not-verified

Daily-to-period reconciliation:
- requests: reported=598931; daily sum=598931; passed
- searches: reported=7545; daily sum=7545; passed
- views: reported=17440; daily sum=17440; passed
- downloads: reported=812; daily sum=812; passed
- sourceClicks: reported=858; daily sum=858; passed
- impressions: reported=104455; daily sum=104455; passed

Definitions:
- requests: Recorded API requests, including automated traffic and probes.
- searches: Recorded search events; repeated searches count separately.
- views: Recorded resource-view events, not all website pageviews or unique people.
- downloads: Recorded download-link clicks, not confirmed file transfers.
- sourceClicks: Recorded source-site link clicks, not confirmed visits or transfers.
- impressions: Recorded appearances of resources in search results.
- trackedVisits: An estimate from merged tab-scoped token sketches; not unique people. Daily estimates must not be added to obtain a period estimate.
- latency: Response times for recorded API requests. Percentiles cannot be added or averaged across months; historical values may come from preserved baselines.

Limitations:
- Reconciliation establishes consistency of recorded data, not capture of every real-world interaction.
- Coverage is the report's recorded declaration, not an independent certification.
- Independent baseline documents and deployed archive durability were not verified by this packet.
- This packet covers the aggregate report only. Detailed rankings, member attribution, client classifications and supplemental dashboard data are outside its verification scope.
- Catalog attribution uses captured metadata, which need not represent month-end inventory.
- Checksums detect changed content; they are not signatures or independent attestations.

Input archive hashes, catalog capture dates, and source-count checks (when supplied) are in evidence.json. Original receipts remain private.
Checksums use SHA-256 over UTF-8 JSON with sorted keys and compact separators. For the report revision omit revision; for the evidence checksum omit evidenceChecksum. The report checksum includes revision. This packet has no external signature.
