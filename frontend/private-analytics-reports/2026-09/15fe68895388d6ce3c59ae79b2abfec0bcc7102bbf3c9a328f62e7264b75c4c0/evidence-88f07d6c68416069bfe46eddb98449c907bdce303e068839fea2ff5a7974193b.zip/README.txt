Report evidence: 2026-09
UTC interval: 2026-09-01 inclusive to 2026-10-01 exclusive
Report revision: 15fe68895388d6ce3c59ae79b2abfec0bcc7102bbf3c9a328f62e7264b75c4c0
Report checksum: 0e76f2ab1c972af4edcf4a8635ccf9ae117bd27bdd22bccba5512dc3e8ab9b6d
Evidence checksum: 88f07d6c68416069bfe46eddb98449c907bdce303e068839fea2ff5a7974193b
Calculation version: 3
Declared source coverage: complete

Verification:
- reportIntegrity: passed
- dailyCalendar: passed
- preservedInputReplay: passed
- independentBaselineEvidence: not-verified
- deployedPreservation: not-verified

Daily-to-period reconciliation:
- requests: reported=475908; daily sum=475908; passed
- searches: reported=5536; daily sum=5536; passed
- views: reported=10497; daily sum=10497; passed
- downloads: reported=876; daily sum=876; passed
- sourceClicks: reported=882; daily sum=882; passed
- impressions: reported=90683; daily sum=90683; passed

Definitions:
- requests: Recorded API requests, including automated traffic and probes.
- searches: Recorded search events; repeated searches count separately.
- views: Recorded resource-view events, not all website pageviews or unique people.
- downloads: Recorded download-link clicks, not confirmed file transfers.
- sourceClicks: Recorded source-site link clicks, not confirmed visits or transfers.
- impressions: Recorded appearances of resources in search results.
- trackedVisits: An estimate from merged tab-scoped token sketches; not unique people. Daily estimates must not be added to obtain a period estimate.
- latency: Response times for recorded API requests. Percentiles cannot be added or averaged across months; historical values may come from preserved baselines.

Limitations:
- Reconciliation establishes consistency of recorded data, not capture of every real-world interaction.
- Coverage is the report's recorded declaration, not an independent certification.
- Independent baseline documents and deployed archive durability were not verified by this packet.
- This packet covers the aggregate report only. Detailed rankings, member attribution, client classifications and supplemental dashboard data are outside its verification scope.
- Catalog attribution uses captured metadata, which need not represent month-end inventory.
- Checksums detect changed content; they are not signatures or independent attestations.

Input archive hashes, catalog capture dates, and source-count checks (when supplied) are in evidence.json. Original receipts remain private.
Checksums use SHA-256 over UTF-8 JSON with sorted keys and compact separators. For the report revision omit revision; for the evidence checksum omit evidenceChecksum. The report checksum includes revision. This packet has no external signature.
