Report evidence: 2026-09
UTC interval: 2026-09-01 inclusive to 2026-10-01 exclusive
Report revision: 64133a77ee68fd5c3479b365435e862a8d83445817e8fe0dd19f7013926346d4
Report checksum: 433246e552c01604f1b2eabb705f38cd8e2b95b9db6cccc1506f98704432ea6f
Evidence checksum: 949e0112883744333f0b0afbb75f92e8c5da572eab784d24f4ec0719d9390cf1
Calculation version: 3
Declared source coverage: complete

Verification:
- reportIntegrity: passed
- dailyCalendar: passed
- preservedInputReplay: passed
- independentBaselineEvidence: not-verified
- deployedPreservation: not-verified

Daily-to-period reconciliation:
- requests: reported=475908; daily sum=475908; passed
- searches: reported=5536; daily sum=5536; passed
- views: reported=10497; daily sum=10497; passed
- downloads: reported=876; daily sum=876; passed
- sourceClicks: reported=882; daily sum=882; passed
- impressions: reported=90683; daily sum=90683; passed

Definitions:
- requests: Recorded API requests, including automated traffic and probes.
- searches: Recorded search events; repeated searches count separately.
- views: Recorded resource-view events, not all website pageviews or unique people.
- downloads: Recorded download-link clicks, not confirmed file transfers.
- sourceClicks: Recorded source-site link clicks, not confirmed visits or transfers.
- impressions: Recorded appearances of resources in search results.
- trackedVisits: An estimate from merged tab-scoped token sketches; not unique people. Daily estimates must not be added to obtain a period estimate.
- latency: Response times for recorded API requests. Percentiles cannot be added or averaged across months; historical values may come from preserved baselines.

Limitations:
- Reconciliation establishes consistency of recorded data, not capture of every real-world interaction.
- Coverage is the report's recorded declaration, not an independent certification.
- Independent baseline documents and deployed archive durability were not verified by this packet.
- This packet covers the aggregate report only. Detailed rankings, member attribution, client classifications and supplemental dashboard data are outside its verification scope.
- Catalog attribution uses captured metadata, which need not represent month-end inventory.
- Checksums detect changed content; they are not signatures or independent attestations.

Input archive hashes, catalog capture dates, and source-count checks (when supplied) are in evidence.json. Original receipts remain private.
Checksums use SHA-256 over UTF-8 JSON with sorted keys and compact separators. For the report revision omit revision; for the evidence checksum omit evidenceChecksum. The report checksum includes revision. This packet has no external signature.
