Report evidence: 2026-07
UTC interval: 2026-07-01 inclusive to 2026-08-01 exclusive
Report revision: 011dfd607ba62a97357877c957d19a013b827f57e8c9af65ea8cbcc904ab1222
Report checksum: b93e1ea9911d5cbba6bd92349f64b5ffc40dc273081e59763a3a3078791034d4
Evidence checksum: 0ce36d037609fcb369b82d7143c3ab576a9ccac2c7ecadd8b826c6e8aafcd7e5
Calculation version: 3
Declared source coverage: incomplete

Verification:
- reportIntegrity: passed
- dailyCalendar: passed
- preservedInputReplay: passed
- independentBaselineEvidence: not-verified
- deployedPreservation: not-verified

Daily-to-period reconciliation:
- requests: reported=613131; daily sum=613131; passed
- searches: reported=6457; daily sum=6457; passed
- views: reported=12200; daily sum=12200; passed
- downloads: reported=933; daily sum=933; passed
- sourceClicks: reported=1129; daily sum=1129; passed
- impressions: reported=99482; daily sum=99482; passed

Definitions:
- requests: Recorded API requests, including automated traffic and probes.
- searches: Recorded search events; repeated searches count separately.
- views: Recorded resource-view events, not all website pageviews or unique people.
- downloads: Recorded download-link clicks, not confirmed file transfers.
- sourceClicks: Recorded source-site link clicks, not confirmed visits or transfers.
- impressions: Recorded appearances of resources in search results.
- trackedVisits: An estimate from merged tab-scoped token sketches; not unique people. Daily estimates must not be added to obtain a period estimate.
- latency: Response times for recorded API requests. Percentiles cannot be added or averaged across months; historical values may come from preserved baselines.

Limitations:
- Reconciliation establishes consistency of recorded data, not capture of every real-world interaction.
- Coverage is the report's recorded declaration, not an independent certification.
- Independent baseline documents and deployed archive durability were not verified by this packet.
- This packet covers the aggregate report only. Detailed rankings, member attribution, client classifications and supplemental dashboard data are outside its verification scope.
- Catalog attribution uses captured metadata, which need not represent month-end inventory.
- Checksums detect changed content; they are not signatures or independent attestations.

Input archive hashes, catalog capture dates, and source-count checks (when supplied) are in evidence.json. Original receipts remain private.
Checksums use SHA-256 over UTF-8 JSON with sorted keys and compact separators. For the report revision omit revision; for the evidence checksum omit evidenceChecksum. The report checksum includes revision. This packet has no external signature.
