Report evidence: 2026-10
UTC interval: 2026-10-01 inclusive to 2026-11-01 exclusive
Report revision: b740a8333198c1771368603ffc9faefba5bd8ffe46f39c1b2b02806e9901568f
Report checksum: 376ea2edf96ae778abaf1a8b3e39463f3bdd42d5cae09ab34745431bf81507d2
Evidence checksum: 46f240acad7293e555f27646c848b2c217bf8c2304ce43e78f3e566ecc55790f
Calculation version: 3
Declared source coverage: complete

Verification:
- reportIntegrity: passed
- dailyCalendar: passed
- preservedInputReplay: passed
- independentBaselineEvidence: not-verified
- deployedPreservation: not-verified

Daily-to-period reconciliation:
- requests: reported=3208142; daily sum=3208142; passed
- searches: reported=7973; daily sum=7973; passed
- views: reported=10577; daily sum=10577; passed
- downloads: reported=551; daily sum=551; passed
- sourceClicks: reported=1049; daily sum=1049; passed
- impressions: reported=130889; daily sum=130889; passed

Definitions:
- requests: Recorded API requests, including automated traffic and probes.
- searches: Recorded search events; repeated searches count separately.
- views: Recorded resource-view events, not all website pageviews or unique people.
- downloads: Recorded download-link clicks, not confirmed file transfers.
- sourceClicks: Recorded source-site link clicks, not confirmed visits or transfers.
- impressions: Recorded appearances of resources in search results.
- trackedVisits: An estimate from merged tab-scoped token sketches; not unique people. Daily estimates must not be added to obtain a period estimate.
- latency: Response times for recorded API requests. Percentiles cannot be added or averaged across months; historical values may come from preserved baselines.

Limitations:
- Reconciliation establishes consistency of recorded data, not capture of every real-world interaction.
- Coverage is the report's recorded declaration, not an independent certification.
- Independent baseline documents and deployed archive durability were not verified by this packet.
- This packet covers the aggregate report only. Detailed rankings, member attribution, client classifications and supplemental dashboard data are outside its verification scope.
- Catalog attribution uses captured metadata, which need not represent month-end inventory.
- Checksums detect changed content; they are not signatures or independent attestations.

Input archive hashes, catalog capture dates, and source-count checks (when supplied) are in evidence.json. Original receipts remain private.
Checksums use SHA-256 over UTF-8 JSON with sorted keys and compact separators. For the report revision omit revision; for the evidence checksum omit evidenceChecksum. The report checksum includes revision. This packet has no external signature.
